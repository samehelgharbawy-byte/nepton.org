require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.use("/api/tickets", require("./routes/tickets"));
app.use("/api/auth", require("./routes/auth"));

// Serve frontend for all non-API routes
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Connect to MongoDB and seed default users
const User = require("./models/User");

async function seedUsers() {
  try {
    const techExists = await User.findOne({ role: "tech" });
    if (!techExists) {
      await User.create({ username: "micheal", password: "Mich@nepton2030", role: "tech" });
      console.log("Tech user created");
    }
    const adminExists = await User.findOne({ role: "admin" });
    if (!adminExists) {
      await User.create({ username: "Admin", password: "hr@netn#2030", role: "admin" });
      console.log("Admin user created");
    }
  } catch (e) {
    console.log("Users already exist or seed error:", e.message);
  }
}

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI;

mongoose
  .connect(MONGODB_URI)
  .then(() => {
    console.log("Connected to MongoDB");
    return seedUsers();
  })
  .then(() => {
    app.listen(PORT, () => console.log(`Nepton IT Support running on port ${PORT}`));
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
    process.exit(1);
  });
