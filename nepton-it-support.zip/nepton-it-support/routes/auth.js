const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Login
router.post("/login", async (req, res) => {
  try {
    const { username, password, role } = req.body;
    const user = await User.findOne({ username, role });
    if (!user) return res.status(401).json({ error: "Invalid credentials" });
    const match = await user.comparePassword(password);
    if (!match) return res.status(401).json({ error: "Invalid credentials" });
    res.json({ success: true, role: user.role, username: user.username });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Reset password
router.post("/reset-password", async (req, res) => {
  try {
    const { role, newPassword } = req.body;
    const user = await User.findOne({ role });
    if (!user) return res.status(404).json({ error: "User not found" });
    user.password = newPassword;
    await user.save();
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
