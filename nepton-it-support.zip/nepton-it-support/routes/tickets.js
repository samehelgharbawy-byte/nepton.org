const express = require("express");
const router = express.Router();
const Ticket = require("../models/Ticket");

// Generate ticket ID
function genId() {
  return "NPN-" + String(Math.floor(Math.random() * 9000) + 1000);
}

// GET all tickets
router.get("/", async (req, res) => {
  try {
    const tickets = await Ticket.find().sort({ createdAt: -1 });
    res.json(tickets);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST new ticket
router.post("/", async (req, res) => {
  try {
    const ticket = new Ticket({ ...req.body, ticketId: genId() });
    await ticket.save();
    res.status(201).json(ticket);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// PUT update ticket (status, assignedTo, notes)
router.put("/:id", async (req, res) => {
  try {
    const ticket = await Ticket.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!ticket) return res.status(404).json({ error: "Not found" });
    res.json(ticket);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// PUT add note
router.put("/:id/note", async (req, res) => {
  try {
    const ticket = await Ticket.findByIdAndUpdate(
      req.params.id,
      { $push: { notes: req.body.note } },
      { new: true }
    );
    if (!ticket) return res.status(404).json({ error: "Not found" });
    res.json(ticket);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// DELETE ticket
router.delete("/:id", async (req, res) => {
  try {
    await Ticket.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// DELETE all tickets
router.delete("/", async (req, res) => {
  try {
    await Ticket.deleteMany({});
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
